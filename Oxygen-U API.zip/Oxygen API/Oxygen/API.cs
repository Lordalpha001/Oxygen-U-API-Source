﻿// Decompiled with JetBrains decompiler
// Type: Oxygen.API
// Assembly: Oxygen API, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: A30AE700-520F-4910-84AD-66723BD40335
// Assembly location: C:\Users\noman\OneDrive\Desktop\nice\Exploit codes\Oxygen u tut\Oxygen u tut\dlls\Oxygen API.dll

using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace Oxygen
{
  public static class API
  {
    private static int injectionms;
    private static int pipems;
    private static bool injecting;

    public static event API.PipeDelegate onInjected;

    public static Task<API.injectionResult> Inject()
    {
      TaskCompletionSource<API.injectionResult> res = new TaskCompletionSource<API.injectionResult>();
      if (!API.injecting)
      {
        new Thread((ThreadStart) (async () =>
        {
          API.injecting = true;
          API.injectionms = 0;
          API.pipems = 0;
          Process proc;
          if (Execution.Exists())
          {
            res.SetResult(API.injectionResult.AlreadyInjected);
            API.injecting = false;
            proc = (Process) null;
          }
          else if (Process.GetProcessesByName("RobloxPlayerBeta").Length < 1)
          {
            res.SetResult(API.injectionResult.RobloxNotFound);
            API.injecting = false;
            proc = (Process) null;
          }
          else
          {
            try
            {
              using (WebClient webClient = new WebClient())
                webClient.DownloadFile("https://github.com/iDevastate/Oxygen-v2/raw/main/OxygenBytecode.vmp.dll", "oxygen.dll");
            }
            catch (Exception ex)
            {
              res.SetResult(API.injectionResult.DLLBlocked);
              System.IO.File.WriteAllText("a.d", ex.ToString());
              API.injecting = false;
              proc = (Process) null;
              return;
            }
            try
            {
              using (WebClient webClient = new WebClient())
              {
                if (!Directory.Exists("bin"))
                  Directory.CreateDirectory("bin");
                webClient.DownloadFile("https://github.com/iDevastate/Oxygen-v2/raw/main/Injector.vmp.exe", "bin\\injector.exe");
              }
            }
            catch
            {
              res.SetResult(API.injectionResult.InjectorBlocked);
              API.injecting = false;
              proc = (Process) null;
              return;
            }
            proc = new Process()
            {
              StartInfo = {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                WorkingDirectory = Environment.CurrentDirectory,
                FileName = Environment.CurrentDirectory + "\\bin\\injector.exe"
              }
            };
            proc.Start();
            while (!proc.HasExited)
            {
              if (API.injectionms >= 10000)
              {
                res.SetResult(API.injectionResult.InjectionFailed);
                API.injecting = false;
                proc = (Process) null;
                return;
              }
              if (Process.GetProcessesByName("RobloxPlayerBeta").Length < 1)
              {
                res.SetResult(API.injectionResult.RobloxNotFound);
                API.injecting = false;
                proc = (Process) null;
                return;
              }
              await Task.Delay(200);
              API.injectionms += 200;
            }
            while (!Execution.Exists())
            {
              if (API.pipems >= 20000)
              {
                res.SetResult(API.injectionResult.InjectionFailed);
                API.injecting = false;
                proc = (Process) null;
                return;
              }
              if (Process.GetProcessesByName("RobloxPlayerBeta").Length < 1)
              {
                res.SetResult(API.injectionResult.RobloxNotFound);
                API.injecting = false;
                proc = (Process) null;
                return;
              }
              await Task.Delay(200);
              API.pipems += 200;
            }
            if (API.onInjected != null)
              API.onInjected();
            res.SetResult(API.injectionResult.Success);
            API.injecting = false;
            proc = (Process) null;
          }
        })).Start();
        return res.Task;
      }
      res.SetResult(API.injectionResult.AlreadyInjecting);
      return res.Task;
    }

    public delegate void PipeDelegate();

    public enum injectionResult
    {
      RobloxNotFound,
      InjectionFailed,
      AlreadyInjected,
      DLLBlocked,
      InjectorBlocked,
      AlreadyInjecting,
      Success,
    }
  }
}
