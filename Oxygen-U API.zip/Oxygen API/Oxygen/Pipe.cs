﻿// Decompiled with JetBrains decompiler
// Type: Oxygen.Pipe
// Assembly: Oxygen API, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: A30AE700-520F-4910-84AD-66723BD40335
// Assembly location: C:\Users\noman\OneDrive\Desktop\nice\Exploit codes\Oxygen u tut\Oxygen u tut\dlls\Oxygen API.dll

using System;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;

namespace Oxygen
{
  internal class Pipe
  {
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern bool WaitNamedPipe(string pipe, int timeout = 10);

    public string Name { get; set; }

    public Pipe(string n) => this.Name = n;

    public bool Exists() => Pipe.WaitNamedPipe("\\\\.\\pipe\\" + this.Name);

    public bool Write(string content)
    {
      if (this.Name == null)
        throw new Exception("Pipe Name was not set.");
      if (string.IsNullOrWhiteSpace(content) || string.IsNullOrEmpty(content) || !this.Exists())
        return false;
      using (NamedPipeClientStream pipeClientStream = new NamedPipeClientStream(".", this.Name, PipeDirection.InOut))
      {
        pipeClientStream.Connect();
        using (StreamWriter streamWriter = new StreamWriter((Stream) pipeClientStream))
          streamWriter.Write(content);
        return true;
      }
    }
  }
}
