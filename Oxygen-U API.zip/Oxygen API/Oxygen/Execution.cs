﻿// Decompiled with JetBrains decompiler
// Type: Oxygen.Execution
// Assembly: Oxygen API, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: A30AE700-520F-4910-84AD-66723BD40335
// Assembly location: C:\Users\noman\OneDrive\Desktop\nice\Exploit codes\Oxygen u tut\Oxygen u tut\dlls\Oxygen API.dll

using System.IO;

namespace Oxygen
{
  public static class Execution
  {
    private static Pipe mainP = new Pipe("OxygenU");

    public static bool Exists() => Execution.mainP.Exists();

    public static Execution.ExecutionResult Execute(string script)
    {
      if (!Execution.mainP.Exists())
        return Execution.ExecutionResult.PipeNotFound;
      if (!File.Exists("oxygen.dll"))
        return Execution.ExecutionResult.DLLNotFound;
      try
      {
        Execution.mainP.Write(script);
        return Execution.ExecutionResult.Success;
      }
      catch
      {
        return Execution.ExecutionResult.Failed;
      }
    }

    public enum ExecutionResult
    {
      Success,
      DLLNotFound,
      PipeNotFound,
      Failed,
    }
  }
}
